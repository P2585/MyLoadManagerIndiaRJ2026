package com.example.myloadmanagerindia

/** Parsed fields are estimates from the visible WhatsApp notification text. */
data class ParsedLoad(
    val company: String,
    val from: String,
    val fromDistrict: String,
    val to: String,
    val toDistrict: String,
    val vehicle: String,
    val tonnage: String,
    val rent: String,
    val phone: String
)

object LoadParser {
    private data class PlaceAlias(val aliases: List<String>, val place: String, val district: String)

    private val places = listOf(
        PlaceAlias(listOf("பென்னாகரம்", "pennagaram", "penagaram"), "பென்னாகரம்", "தர்மபுரி"),
        PlaceAlias(listOf("தர்மபுரி", "dharmapuri", "dharamapuri"), "தர்மபுரி", "தர்மபுரி"),
        PlaceAlias(listOf("காங்கயம்", "kangayam"), "காங்கயம்", "திருப்பூர்"),
        PlaceAlias(listOf("திருப்பூர்", "tiruppur", "tirupur"), "திருப்பூர்", "திருப்பூர்"),
        PlaceAlias(listOf("கோயம்புத்தூர்", "கோவை", "coimbatore", "kovai"), "கோயம்புத்தூர்", "கோயம்புத்தூர்"),
        PlaceAlias(listOf("ஈரோடு", "erode"), "ஈரோடு", "ஈரோடு"),
        PlaceAlias(listOf("சேலம்", "salem"), "சேலம்", "சேலம்"),
        PlaceAlias(listOf("நாமக்கல்", "namakkal"), "நாமக்கல்", "நாமக்கல்"),
        PlaceAlias(listOf("கரூர்", "karur"), "கரூர்", "கரூர்"),
        PlaceAlias(listOf("சென்னை", "chennai", "madras"), "சென்னை", "சென்னை"),
        PlaceAlias(listOf("மணலி", "manali"), "மணலி", "சென்னை"),
        PlaceAlias(listOf("மதுரை", "madurai"), "மதுரை", "மதுரை"),
        PlaceAlias(listOf("திருச்சி", "திருச்சிராப்பள்ளி", "trichy", "tiruchirappalli"), "திருச்சி", "திருச்சிராப்பள்ளி"),
        PlaceAlias(listOf("திண்டுக்கல்", "dindigul"), "திண்டுக்கல்", "திண்டுக்கல்"),
        PlaceAlias(listOf("விருதுநகர்", "virudhunagar"), "விருதுநகர்", "விருதுநகர்"),
        PlaceAlias(listOf("தேனி", "theni"), "தேனி", "தேனி"),
        PlaceAlias(listOf("சிவகங்கை", "sivaganga"), "சிவகங்கை", "சிவகங்கை"),
        PlaceAlias(listOf("ராமநாதபுரம்", "ramanathapuram", "ramnad"), "ராமநாதபுரம்", "ராமநாதபுரம்"),
        PlaceAlias(listOf("தூத்துக்குடி", "thoothukudi", "tuticorin"), "தூத்துக்குடி", "தூத்துக்குடி"),
        PlaceAlias(listOf("திருநெல்வேலி", "tirunelveli"), "திருநெல்வேலி", "திருநெல்வேலி"),
        PlaceAlias(listOf("தென்காசி", "tenkasi"), "தென்காசி", "தென்காசி"),
        PlaceAlias(listOf("கன்னியாகுமரி", "kanyakumari", "nagercoil", "நாகர்கோவில்"), "நாகர்கோவில்", "கன்னியாகுமரி"),
        PlaceAlias(listOf("விழுப்புரம்", "viluppuram", "villupuram"), "விழுப்புரம்", "விழுப்புரம்"),
        PlaceAlias(listOf("கள்ளக்குறிச்சி", "kallakurichi"), "கள்ளக்குறிச்சி", "கள்ளக்குறிச்சி"),
        PlaceAlias(listOf("கடலூர்", "cuddalore", "kadalur"), "கடலூர்", "கடலூர்"),
        PlaceAlias(listOf("மயிலாடுதுறை", "mayiladuthurai"), "மயிலாடுதுறை", "மயிலாடுதுறை"),
        PlaceAlias(listOf("நாகப்பட்டினம்", "nagapattinam"), "நாகப்பட்டினம்", "நாகப்பட்டினம்"),
        PlaceAlias(listOf("திருவாரூர்", "thiruvarur"), "திருவாரூர்", "திருவாரூர்"),
        PlaceAlias(listOf("தஞ்சாவூர்", "thanjavur", "tanjore"), "தஞ்சாவூர்", "தஞ்சாவூர்"),
        PlaceAlias(listOf("புதுக்கோட்டை", "pudukkottai"), "புதுக்கோட்டை", "புதுக்கோட்டை"),
        PlaceAlias(listOf("அரியலூர்", "ariyalur"), "அரியலூர்", "அரியலூர்"),
        PlaceAlias(listOf("பெரம்பலூர்", "perambalur"), "பெரம்பலூர்", "பெரம்பலூர்"),
        PlaceAlias(listOf("திருவண்ணாமலை", "tiruvannamalai"), "திருவண்ணாமலை", "திருவண்ணாமலை"),
        PlaceAlias(listOf("வேலூர்", "vellore"), "வேலூர்", "வேலூர்"),
        PlaceAlias(listOf("ராணிப்பேட்டை", "ranipet"), "ராணிப்பேட்டை", "ராணிப்பேட்டை"),
        PlaceAlias(listOf("திருப்பத்தூர்", "tirupattur"), "திருப்பத்தூர்", "திருப்பத்தூர்"),
        PlaceAlias(listOf("கிருஷ்ணகிரி", "krishnagiri"), "கிருஷ்ணகிரி", "கிருஷ்ணகிரி"),
        PlaceAlias(listOf("ஊட்டி", "உதகமண்டலம்", "ooty", "udhagamandalam"), "ஊட்டி", "நீலகிரி"),
        PlaceAlias(listOf("பெங்களூரு", "bengaluru", "bangalore"), "பெங்களூரு", "பெங்களூரு நகரம்"),
        PlaceAlias(listOf("திருவனந்தபுரம்", "thiruvananthapuram", "trivandrum"), "திருவனந்தபுரம்", "திருவனந்தபுரம்")
    )

    private val phoneRegex = Regex("(?<!\\d)([6-9]\\d{9})(?!\\d)")
    private val tonRegex = Regex("(?i)(\\d+(?:\\.\\d+)?)\\s*(?:tonnes?|tons?|டன்)")
    private val feetRegex = Regex("(?i)(\\d{1,2})\\s*(?:feet|foot|ft|பீட்|அடி)")
    private val wheelRegex = Regex("(?i)(\\d+)\\s*(?:wh|wheel|சக்கர)")
    private val rentRegex = Regex("(?i)(?:ரூ\\.?|rs\\.?|inr|₹)\\s*([\\d,]+)|([\\d,]+)\\s*(?:ரூபாய்|ரூ\\.?|rs\\.?|inr|₹)")

    fun parse(message: String): ParsedLoad {
        val lines = message.lines().map { it.trim() }.filter { it.isNotBlank() }
        val fromIndex = lines.indexOfFirst { it.equals("to", true) || it.equals("to:", true) || it.equals("டூ", true) }
        val fromText = if (fromIndex > 0) lines.subList(0, fromIndex).joinToString(" ") else message
        val toText = if (fromIndex >= 0 && fromIndex + 1 < lines.size) lines.drop(fromIndex + 1).joinToString(" ") else message
        val fromMatch = findPlace(fromText)
        val toMatch = findPlace(toText, fromMatch?.place)
        val company = lines.firstOrNull { it.contains("transport", true) || it.contains("transports", true) }
            ?.takeIf { it.none(Char::isDigit) }?.trim().orEmpty()
        val ton = tonRegex.find(message)?.groupValues?.getOrNull(1)?.let { "$it டன்" }.orEmpty()
        val feet = feetRegex.find(message)?.groupValues?.getOrNull(1)?.let { "$it அடி" }.orEmpty()
        val open = if (message.contains("open", true) || message.contains("ஓபன்")) "ஓபன்" else ""
        val wheels = wheelRegex.find(message)?.groupValues?.getOrNull(1)?.let { "$it சக்கரம்" }.orEmpty()
        val rentMatch = rentRegex.find(message)
        val rent = (rentMatch?.groupValues?.getOrNull(1)?.takeIf { it.isNotBlank() }
            ?: rentMatch?.groupValues?.getOrNull(2)?.takeIf { it.isNotBlank() })?.let { "₹${it.replace(",", "")}" }.orEmpty()
        return ParsedLoad(
            company = company,
            from = fromMatch?.place.orEmpty(),
            fromDistrict = fromMatch?.district.orEmpty(),
            to = toMatch?.place.orEmpty(),
            toDistrict = toMatch?.district.orEmpty(),
            vehicle = listOf(feet, open, wheels).filter { it.isNotBlank() }.joinToString(" "),
            tonnage = ton,
            rent = rent,
            phone = phoneRegex.find(message)?.groupValues?.getOrNull(1).orEmpty()
        )
    }

    private fun findPlace(text: String, excludePlace: String? = null): PlaceAlias? {
        val normalized = text.lowercase()
        return places.firstOrNull { place ->
            place.place != excludePlace && place.aliases.any { alias ->
                Regex("(?<![\\p{L}\\p{N}])" + Regex.escape(alias.lowercase()) + "(?![\\p{L}\\p{N}])").containsMatchIn(normalized)
            }
        }
    }
}
