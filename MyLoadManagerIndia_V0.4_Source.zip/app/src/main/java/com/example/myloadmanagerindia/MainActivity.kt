package com.example.myloadmanagerindia

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val heading = TextView(this).apply {
            text = "My Load Manager India"
            textSize = 23f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "WhatsApp அறிவிப்புகளில் உள்ள லோடு விவரங்கள் மட்டும் தேர்வு செய்து சேமிக்கப்படும். முழு செய்தி அல்லது சாதாரண உரையாடல் சேமிக்கப்படாது. SMS மற்றும் Accessibility அனுமதிகள் தேவையில்லை."
            textSize = 14f
            setPadding(0, 16, 0, 16)
        }
        val settingsButton = Button(this).apply {
            text = "Notification Access அமைப்பைத் திற"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        val refreshButton = Button(this).apply {
            text = "லோடுகளை புதுப்பிக்க"
            setOnClickListener { showLoads() }
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(listBox) }

        root.addView(heading)
        root.addView(info)
        root.addView(settingsButton)
        root.addView(refreshButton)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        showLoads()
    }

    override fun onResume() {
        super.onResume()
        if (::listBox.isInitialized) showLoads()
    }

    private fun showLoads() {
        listBox.removeAllViews()
        LoadDb(this).use { helper ->
            val cursor = helper.readableDatabase.rawQuery(
                "SELECT company, from_place, from_district, to_place, to_district, vehicle, tonnage, rent, phone, received_at FROM loads ORDER BY received_at DESC",
                null
            )
            cursor.use {
                if (it.count == 0) {
                    addText("இன்னும் லோடு தகவல் வரவில்லை. WhatsApp-ல் புதிய லோடு அறிவிப்பு வந்த பிறகு இங்கே புதுப்பிக்கவும்.")
                }
                while (it.moveToNext()) {
                    val company = it.getString(0).orEmpty()
                    val from = it.getString(1).orEmpty()
                    val fromDistrict = it.getString(2).orEmpty()
                    val to = it.getString(3).orEmpty()
                    val toDistrict = it.getString(4).orEmpty()
                    val vehicle = it.getString(5).orEmpty()
                    val tonnage = it.getString(6).orEmpty()
                    val rent = it.getString(7).orEmpty()
                    val phone = it.getString(8).orEmpty()
                    val time = it.getLong(9)
                    val date = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(Date(time))
                    val details = buildString {
                        if (company.isNotBlank()) append("நிறுவனம்: $company\n")
                        append("புறப்படும் இடம்: ${from.ifBlank { "கண்டறியப்படவில்லை" }}")
                        if (fromDistrict.isNotBlank()) append(" ($fromDistrict மாவட்டம்)")
                        append("\nசெல்லும் இடம்: ${to.ifBlank { "கண்டறியப்படவில்லை" }}")
                        if (toDistrict.isNotBlank()) append(" ($toDistrict மாவட்டம்)")
                        if (tonnage.isNotBlank()) append("\nஎடை: $tonnage")
                        if (rent.isNotBlank()) append("\nவாடகை: $rent")
                        if (vehicle.isNotBlank()) append("\nவாகனம்: $vehicle")
                        if (phone.isNotBlank()) append("\nதொடர்பு: $phone")
                        append("\nபெற்ற நேரம்: $date")
                    }
                    addText(details)
                }
            }
        }
    }

    private fun addText(value: String) {
        val view = TextView(this).apply {
            text = value
            textSize = 15f
            setPadding(12, 16, 12, 16)
        }
        listBox.addView(view)
        val divider = android.view.View(this).apply { setBackgroundColor(0xFFCCCCCC.toInt()) }
        listBox.addView(divider, LinearLayout.LayoutParams(-1, 1))
    }
}
