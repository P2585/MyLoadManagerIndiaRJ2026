package com.example.myloadmanagerindia

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Stores extracted load fields only. Raw WhatsApp notification text is never saved. */
class LoadDb(context: android.content.Context) :
    SQLiteOpenHelper(context, "loads.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS loads (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "company TEXT, from_place TEXT, from_district TEXT, " +
                "to_place TEXT, to_district TEXT, vehicle TEXT, tonnage TEXT, " +
                "rent TEXT, phone TEXT, received_at INTEGER)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Version 1 stored complete notification text. Delete it during the privacy upgrade.
        db.execSQL("DROP TABLE IF EXISTS loads")
        onCreate(db)
    }
}

class WhatsAppNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return

        val extras = sbn.notification.extras
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        val bigText = extras.getCharSequence("android.bigText")?.toString().orEmpty()
        val body = if (bigText.isNotBlank()) bigText else text
        if (body.isBlank()) return

        val parsed = LoadParser.parse(body)
        // Save only messages that look like actual load offers, not ordinary chat.
        val hasRoute = parsed.from.isNotBlank() && parsed.to.isNotBlank()
        val hasLoadDetail = parsed.vehicle.isNotBlank() || parsed.tonnage.isNotBlank() ||
            parsed.rent.isNotBlank() || body.contains("load", true) || body.contains("லோடு")
        if (!hasRoute || !hasLoadDetail) return

        val values = ContentValues().apply {
            put("company", parsed.company)
            put("from_place", parsed.from)
            put("from_district", parsed.fromDistrict)
            put("to_place", parsed.to)
            put("to_district", parsed.toDistrict)
            put("vehicle", parsed.vehicle)
            put("tonnage", parsed.tonnage)
            put("rent", parsed.rent)
            put("phone", parsed.phone)
            put("received_at", sbn.postTime)
        }
        LoadDb(applicationContext).use { helper ->
            helper.writableDatabase.insert("loads", null, values)
        }
    }
}
